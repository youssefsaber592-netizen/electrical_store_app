import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeManager extends ChangeNotifier {
  bool _isDarkMode = false;

  bool get isDarkMode => _isDarkMode;

  ThemeManager() {
    _loadThemeFromPrefs();
  }

  // دالة تبديل الثيم (فاتح / داكن)
  void toggleTheme(bool isOn) async {
    _isDarkMode = isOn;
    notifyListeners(); // إعلام التطبيق بالكامل بالتحديث فوراً

    // حفظ الاختيار داخلياً في الجهاز
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', isOn);
  }

  // دالة تحميل الثيم المحفوظ عند فتح الأبليكيشن لأول مرة
  void _loadThemeFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('isDarkMode') ?? false;
    notifyListeners();
  }
}