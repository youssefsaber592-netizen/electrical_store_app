import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// متغيرات عامة للتطبيق
String currentLanguage = "العربية";
bool isDarkMode = false;

// نصوص الترجمة الثابتة للتطبيق (تمت إضافة كلمات المفضلة هنا)
const Map<String, Map<String, String>> _localizedValues = {
  "العربية": {
    "title": "متجر الإلكترونيات",
    "settings": "الإعدادات",
    "lang_label": "لغة التطبيق الحالية",
    "save": "حفظ الإعدادات",
    "favorites": "المفضلة",
    "no_favorites": "لا توجد عناصر في المفضلة",
  },
  "English": {
    "title": "Electronics Store",
    "settings": "Settings",
    "lang_label": "Current App Language",
    "save": "Save Settings",
    "favorites": "Favorites",
    "no_favorites": "No items in favorites",
  }
};

String getTranslated(String key) {
  return _localizedValues[currentLanguage]?[key] ?? key;
}

// دالة تحميل الإعدادات المحفوظة عند فتح الأبليكيشن
Future<void> loadSavedSettings() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    currentLanguage = prefs.getString('lang') ?? "العربية";
    isDarkMode = prefs.getBool('dark') ?? false;
  } catch (e) {
    // لتفادي أي مشاكل أثناء التحميل الأولي
    currentLanguage = "العربية";
    isDarkMode = false;
  }
}

// دالة حفظ الإعدادات داخلياً في الجهاز
Future<void> saveAppSettings(String lang, bool dark) async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('lang', lang);
    await prefs.setBool('dark', dark);
    currentLanguage = lang;
    isDarkMode = dark;
  } catch (e) {
    debugPrint("Error saving settings: $e");
  }
}