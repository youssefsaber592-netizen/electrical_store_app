import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';
import 'package:store_app/language_manager.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool isArabic = currentLanguage == "العربية";

    // حساب المجموع الإجمالي ديناميكياً بناءً على الأسعار والكميات في السلة
    double subTotal = cartProducts.fold(0, (sum, item) => sum + (item.price * item.quantity));
    double shipping = subTotal > 0 ? 15.0 : 0.0;
    double total = subTotal + shipping;

    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        title: Text(isArabic ? "إتمام الشراء" : "Checkout", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: kPrimaryColor,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(kDefaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isArabic ? "ملخص الفاتورة:" : "Order Summary:",
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: kPrimaryColor),
            ),
            const SizedBox(height: 15),

            // كارت عرض تفاصيل الحساب
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10)],
              ),
              child: Column(
                children: [
                  _buildSummaryRow(isArabic ? "المجموع الفرعي" : "Subtotal", "\$$subTotal"),
                  const SizedBox(height: 12),
                  _buildSummaryRow(isArabic ? "مصاريف الشحن" : "Shipping Fee", "\$$shipping"),
                  const Divider(height: 30, thickness: 1.2),
                  _buildSummaryRow(
                      isArabic ? "الإجمالي النهائي" : "Total Amount",
                      "\$$total",
                      isTotal: true
                  ),
                ],
              ),
            ),
            const Spacer(),

            // زرار تأكيد الطلب السحري
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kSecondaryColor,
                minimumSize: const Size(double.infinity, 55),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              onPressed: () {
                // مسح السلة بعد نجاح الشراء
                cartProducts.clear();

                // إظهار رسالة النجاح الاحترافية
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => AlertDialog(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    title: const Icon(Icons.check_circle, color: Colors.green, size: 70),
                    content: Text(
                      isArabic ? "تم تأكيد طلبك بنجاح! شكراً لشرائك من متجرنا." : "Your order has been placed successfully! Thank you for shopping.",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context); // قفل الحوار
                          Navigator.pop(context); // العودة من الـ checkout
                          Navigator.pop(context); // العودة للرئيسية
                        },
                        child: Text(isArabic ? "موافق" : "OK", style: const TextStyle(color: kPrimaryColor, fontWeight: FontWeight.bold)),
                      )
                    ],
                  ),
                );
              },
              child: Text(
                  isArabic ? "تأكيد وطلب الآن" : "Confirm & Place Order",
                  style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String title, String value, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
            title,
            style: TextStyle(
                fontSize: isTotal ? 18 : 15,
                fontWeight: isTotal ? FontWeight.bold : FontWeight.w500,
                color: isTotal ? kPrimaryColor : Colors.grey[700]
            )
        ),
        Text(
            value,
            style: TextStyle(
                fontSize: isTotal ? 20 : 16,
                fontWeight: FontWeight.bold,
                color: isTotal ? kSecondaryColor : Colors.black
            )
        ),
      ],
    );
  }
}