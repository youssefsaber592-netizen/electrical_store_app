import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';

class FeaturedScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("أجهزة مميزة"), backgroundColor: kPrimaryColor),
      body: GridView.builder(
        padding: EdgeInsets.all(kDefaultPadding),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.8,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10
        ),
        itemCount: products.length,
        itemBuilder: (context, index) => Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: Column(
            children: [
              Expanded(child: Image.asset(products[index].image)),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(products[index].title, style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              Icon(Icons.star, color: Colors.amber, size: 20),
              SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }
}