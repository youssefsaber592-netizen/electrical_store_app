import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/screens/home_screen.dart';
import 'package:store_app/language_manager.dart';
import 'package:firebase_auth/firebase_auth.dart'; // 👈 استيراد الفايربيز للتحقق من الحساب

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isObscure = true;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // 👈 دالة إظهار التنبيه الشيك لو اليوزر مش مسجل
  void _showRegisterAlert() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: const Text("Access Denied", style: TextStyle(fontWeight: FontWeight.bold, color: kPrimaryColor)),
          content: const Text("This account is not registered. Please sign up first to access the electrical store."),
          actions: [
            TextButton(
              child: const Text("OK", style: TextStyle(color: kPrimaryColor, fontSize: 16)),
              onPressed: () {
                Navigator.of(context).pop(); // يقفل الإشعار
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding * 1.5),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.lock_person_outlined, size: 90, color: kPrimaryColor),
                  const SizedBox(height: 20),
                  Text(
                    getTranslated("welcome"),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: kPrimaryColor),
                  ),
                  const SizedBox(height: 40),

                  // حقل الإيميل
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    textAlign: currentLanguage == "العربية" ? TextAlign.right : TextAlign.left,
                    decoration: InputDecoration(
                      labelText: getTranslated("email"),
                      prefixIcon: const Icon(Icons.email_outlined, color: kPrimaryColor),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    validator: (value) {
                      if (value == null || !value.contains('@')) {
                        return getTranslated("email_error");
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),

                  // حقل الباسورد
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _isObscure,
                    textAlign: currentLanguage == "العربية" ? TextAlign.right : TextAlign.left,
                    decoration: InputDecoration(
                      labelText: getTranslated("password"),
                      prefixIcon: const Icon(Icons.lock_outlined, color: kPrimaryColor),
                      suffixIcon: IconButton(
                        icon: Icon(_isObscure ? Icons.visibility_off : Icons.visibility, color: kPrimaryColor),
                        onPressed: () {
                          setState(() {
                            _isObscure = !_isObscure;
                          });
                        },
                      ),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    validator: (value) {
                      if (value == null || value.length < 6) {
                        return getTranslated("password_error");
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 35),

                  // زر الدخول المعدل بالفايربيز والتنبيه
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPrimaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        try {
                          // محاولة تسجيل الدخول بالفايربيز للتأكد من وجود الحساب
                          await FirebaseAuth.instance.signInWithEmailAndPassword(
                            email: _emailController.text.trim(),
                            password: _passwordController.text.trim(),
                          );

                          // لو الحساب موجود وصح، يدخل الشاشة الرئيسية فوراً
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => HomeScreen()),
                          );
                        } on FirebaseAuthException catch (e) {
                          // لو الفايربيز رجع خطأ إن المستخدم مش موجود (user-not-found) يظهر التنبيه
                          if (e.code == 'user-not-found') {
                            _showRegisterAlert();
                          } else {
                            // لأي خطأ آخر (زي كلمة مرور غلط) بيظهر سناك بار عادي
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(e.message ?? "Authentication failed")),
                            );
                          }
                        }
                      }
                    },
                    child: Text(getTranslated("login"), style: const TextStyle(color: Colors.white, fontSize: 18)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}