import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';
import 'package:store_app/language_manager.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String tempLanguage = currentLanguage;
  bool isNotificationOn = true;
  late TextEditingController _nameController;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: globalUserName);
  }

  Future<void> _pickProfileImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) {
        final Uint8List imageBytes = await pickedFile.readAsBytes();
        setState(() {
          globalProfileImageBytes = imageBytes;
          globalProfileImage = pickedFile.path;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("عذراً، حدث خطأ أثناء اختيار الصورة")),
      );
    }
  }

  void _showImageSourceBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          height: 180,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                currentLanguage == "العربية" ? "تحديث صورة البروفايل عبر:" : "Update Profile Image via:",
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
                    icon: const Icon(Icons.photo_library, color: Colors.white),
                    label: Text(currentLanguage == "العربية" ? "المعرض" : "Gallery", style: const TextStyle(color: Colors.white)),
                    onPressed: () {
                      Navigator.pop(context);
                      _pickProfileImage(ImageSource.gallery);
                    },
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: kSecondaryColor),
                    icon: const Icon(Icons.camera_alt, color: Colors.white),
                    label: Text(currentLanguage == "العربية" ? "الكاميرا" : "Camera", style: const TextStyle(color: Colors.white)),
                    onPressed: () {
                      Navigator.pop(context);
                      _pickProfileImage(ImageSource.camera);
                    },
                  ),
                ],
              )
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isArabic = currentLanguage == "العربية";

    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        title: Text(getTranslated("settings"), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: kPrimaryColor,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(kDefaultPadding),
        child: Column(
          children: [
            const SizedBox(height: 10),
            Center(
              child: Column(
                children: [
                  Stack(
                    children: [
                      CircleAvatar(
                        radius: 55,
                        backgroundColor: kPrimaryColor.withOpacity(0.15),
                        backgroundImage: globalProfileImageBytes != null
                            ? MemoryImage(globalProfileImageBytes)
                            : null,
                        child: globalProfileImageBytes == null
                            ? const Icon(Icons.person, size: 65, color: kPrimaryColor)
                            : null,
                      ),
                      Positioned(
                        bottom: 0,
                        right: 4,
                        child: GestureDetector(
                          onTap: _showImageSourceBottomSheet,
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(color: kSecondaryColor, shape: BoxShape.circle),
                            child: const Icon(Icons.camera_alt, color: Colors.white, size: 18),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(globalUserName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text(globalUserEmail, style: const TextStyle(fontSize: 14, color: Colors.grey)),
                ],
              ),
            ),
            const SizedBox(height: 30),

            _buildSettingsCard(
              icon: Icons.person_outline,
              title: isArabic ? "اسم المستخدم" : "Username", // تعديل ذكي للترجمة
              child: TextField(
                controller: _nameController,
                style: const TextStyle(fontSize: 15),
                decoration: const InputDecoration(border: InputBorder.none),
              ),
            ),
            const SizedBox(height: 15),

            _buildSettingsCard(
              icon: Icons.notifications_none_outlined,
              title: isArabic ? "الإشعارات" : "Notifications", // تعديل ذكي للترجمة
              child: Align(
                alignment: isArabic ? Alignment.centerLeft : Alignment.centerRight,
                child: Switch(
                  value: isNotificationOn,
                  activeColor: kPrimaryColor,
                  onChanged: (v) => setState(() => isNotificationOn = v),
                ),
              ),
            ),
            const SizedBox(height: 15),

            _buildSettingsCard(
              icon: Icons.language_outlined,
              title: getTranslated("lang_label"),
              child: DropdownButton<String>(
                value: tempLanguage,
                isExpanded: true,
                underline: const SizedBox(),
                items: ["العربية", "English"].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (value) => setState(() => tempLanguage = value!),
              ),
            ),

            const SizedBox(height: 40),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kPrimaryColor,
                minimumSize: const Size(double.infinity, 55),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              onPressed: () {
                setState(() {
                  currentLanguage = tempLanguage;
                  globalUserName = _nameController.text;
                });
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content: Text(currentLanguage == "العربية" ? "تم حفظ الإعدادات بنجاح" : "Settings saved successfully"),
                        backgroundColor: Colors.green
                    )
                );
              },
              child: Text(getTranslated("save"), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsCard({required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Row(
        children: [
          Icon(icon, color: kPrimaryColor, size: 26),
          const SizedBox(width: 15),
          Expanded(flex: 3, child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16))),
          Expanded(flex: 3, child: child),
        ],
      ),
    );
  }
}