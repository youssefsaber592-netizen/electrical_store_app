import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';
import 'package:store_app/language_manager.dart';
import 'package:store_app/screens/checkout_screen.dart'; // استدعاء شاشة الفاتورة الجديدة

class CartScreen extends StatefulWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    bool isArabic = currentLanguage == "العربية";

    // حساب المجموع الإجمالي ديناميكياً لعرضه أسفل السلة
    double totalCartPrice = cartProducts.fold(0, (sum, item) => sum + (item.price * item.quantity));

    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kPrimaryColor,
        elevation: 0,
        title: Text(
          isArabic ? "سلة المشتريات" : "Shopping Cart",
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: cartProducts.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_cart_outlined, size: 80, color: kPrimaryColor.withOpacity(0.5)),
            const SizedBox(height: 15),
            Text(
              isArabic ? "سلتك فارغة حالياً!" : "Your cart is currently empty!",
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kPrimaryColor),
            ),
          ],
        ),
      )
          : Column(
        children: [
          // قائمة المنتجات المضافة داخل السلة
          Expanded(
            child: ListView.builder(
              itemCount: cartProducts.length,
              itemBuilder: (context, index) {
                final item = cartProducts[index];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8)],
                  ),
                  child: Row(
                    children: [
                      Image.asset(item.image, width: 70, height: 70, fit: BoxFit.contain),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item.title,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              isArabic ? "السعر: \$${item.price}" : "Price: \$${item.price}",
                              style: const TextStyle(color: kSecondaryColor, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              isArabic ? "الكمية: ${item.quantity}" : "Qty: ${item.quantity}",
                              style: TextStyle(color: Colors.grey[600], fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                      // زرار الحذف السريع من السلة
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            cartProducts.removeAt(index);
                          });
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          // الجزء السفلي: يعرض الإجمالي وزرار الانتقال لشاشة الفاتورة
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, -4))],
            ),
            child: SafeArea(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        isArabic ? "المجموع الفرعي:" : "Subtotal:",
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "\$$totalCartPrice",
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kSecondaryColor),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPrimaryColor,
                      minimumSize: const Size(double.infinity, 55),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    onPressed: () {
                      // التحقق من السلة قبل الانتقال لشاشة الفاتورة
                      if (cartProducts.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(isArabic ? "السلة فارغة!" : "Cart is empty!"),
                              backgroundColor: Colors.red,
                            )
                        );
                      } else {
                        // كود الانتقال السحري لشاشة الفاتورة وإتمام الشراء
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const CheckoutScreen()),
                        ).then((value) {
                          // تحديث صفحة السلة الحالية فور العودة (عشان لو السلة اتصفرت تحس فوراً)
                          setState(() {});
                        });
                      }
                    },
                    child: Text(
                      isArabic ? "الانتقال للدفع والشحن" : "Proceed to Checkout",
                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}