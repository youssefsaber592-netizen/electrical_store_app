import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';
import 'package:store_app/language_manager.dart'; // استدعاء مدير اللغة

class DetailsScreen extends StatefulWidget {
  final Product product;

  const DetailsScreen({Key? key, required this.product}) : super(key: key);

  @override
  State<DetailsScreen> createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  @override
  Widget build(BuildContext context) {
    bool isArabic = currentLanguage == "العربية";
    bool isAddedToCart = cartProducts.any((item) => item.id == widget.product.id);

    return Scaffold(
      backgroundColor: kPrimaryColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kPrimaryColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          isArabic ? "التفاصيل" : "Details",
          style: const TextStyle(color: kPrimaryColor, fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding),
              decoration: const BoxDecoration(
                color: kBackgroundColor,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(50),
                  bottomRight: Radius.circular(50),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: kDefaultPadding),
                      height: 250,
                      child: Image.asset(widget.product.image, fit: BoxFit.contain),
                    ),
                  ),
                  const SizedBox(height: kDefaultPadding),
                  Text(
                    widget.product.title, // الاسم الذكي المترجم
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    isArabic ? "السعر: \$${widget.product.price}" : "Price: \$${widget.product.price}",
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: kSecondaryColor),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
            // تم تعديل السطر ده هنا وحذفنا الخاصية المسببة للمشكلة
            Container(
              padding: const EdgeInsets.all(kDefaultPadding),
              child: Text(
                widget.product.description, // الوصف الذكي المترجم
                style: const TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.all(kDefaultPadding),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: isAddedToCart ? Colors.green : kSecondaryColor,
                  minimumSize: const Size(double.infinity, 55),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                onPressed: () {
                  setState(() {
                    if (isAddedToCart) {
                      cartProducts.removeWhere((item) => item.id == widget.product.id);
                    } else {
                      cartProducts.add(widget.product);
                    }
                  });
                },
                child: Text(
                  isAddedToCart
                      ? (isArabic ? "موجود في السلة (اضغط للحذف)" : "In Cart (Click to remove)")
                      : (isArabic ? "إضافة إلى السلة" : "Add to Cart"),
                  style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}