import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../constants.dart';
import '../models/product.dart';
import 'home_screen.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isLogin = true;
  bool _isObscure = true;
  bool _isLoading = false; // لمؤشر التحميل عند الضغط على الزرار

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _addressController = TextEditingController(); // كنترولر العنوان الجديد

  // دالة التعامل مع الفايربيز (تسجيل الدخول أو إنشاء حساب جديد)
  void _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      if (_isLogin) {
        // 1. تسجيل الدخول بالفايربيز
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        globalUserName = _emailController.text.split('@')[0];
        globalUserEmail = _emailController.text.trim();

      } else {
        // 2. إنشاء حساب جديد في الـ Authentication
        UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        // 3. حفظ بيانات المستخدم وعنوانه في الـ Firestore Database
        await FirebaseFirestore.instance.collection('users').doc(userCredential.user!.uid).set({
          'name': _nameController.text.trim(),
          'email': _emailController.text.trim(),
          'address': _addressController.text.trim(), // حفظ العنوان هنا
          'createdAt': Timestamp.now(),
        });

        globalUserName = _nameController.text.trim();
        globalUserEmail = _emailController.text.trim();
      }

      // الانتقال للصفحة الرئيسية بعد النجاح
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      }
    } on FirebaseAuthException catch (e) {
      // إظهار رسالة خطأ لو الباسورد ضعيف أو الإيميل مستخدم
      String errorMessage = "حدث خطأ ما، يرجى المحاولة لاحقاً";
      if (e.code == 'weak-password') {
        errorMessage = 'كلمة المرور ضعيفة جداً.';
      } else if (e.code == 'email-already-in-use') {
        errorMessage = 'هذا البريد الإلكتروني مستخدم بالفعل.';
      } else if (e.code == 'user-not-found') {
        errorMessage = 'لم يتم العثور على حساب بهذا البريد.';
      } else if (e.code == 'wrong-password') {
        errorMessage = 'كلمة المرور غير صحيحة.';
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage, textAlign: TextAlign.center), backgroundColor: Colors.red),
      );
    } catch (e) {
      print(e);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding * 1.5),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(
                      _isLogin ? Icons.lock_open_outlined : Icons.person_add_alt_1_outlined,
                      size: 90,
                      color: kPrimaryColor
                  ),
                  const SizedBox(height: 15),
                  Text(
                    _isLogin ? "تسجيل الدخول" : "إنشاء حساب جديد",
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: kPrimaryColor),
                  ),
                  const SizedBox(height: 35),

                  if (!_isLogin) ...[
                    // خانة الاسم الكامل
                    TextFormField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        labelText: "الاسم الكامل",
                        prefixIcon: const Icon(Icons.person_outline, color: kPrimaryColor),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                      ),
                      validator: (value) => value == null || value.isEmpty ? 'يرجى إدخال الاسم' : null,
                    ),
                    const SizedBox(height: 20),

                    // خانة العنوان الجديدة بالتفصيل
                    TextFormField(
                      controller: _addressController,
                      decoration: InputDecoration(
                        labelText: "العنوان بالتفصيل (المحافظة/المدينة/الشارع)",
                        prefixIcon: const Icon(Icons.location_on_outlined, color: kPrimaryColor),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                      ),
                      validator: (value) => value == null || value.isEmpty ? 'يرجى إدخال عنوانك بالتفصيل لتوصيل الطلبات' : null,
                    ),
                    const SizedBox(height: 20),
                  ],

                  // خانة البريد الإلكتروني
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      labelText: "البريد الإلكتروني",
                      prefixIcon: const Icon(Icons.email_outlined, color: kPrimaryColor),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    validator: (value) => value != null && value.contains('@') ? null : 'يرجى إدخال بريد صحيح',
                  ),
                  const SizedBox(height: 20),

                  // خانة كلمة المرور
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _isObscure,
                    decoration: InputDecoration(
                      labelText: "كلمة المرور",
                      prefixIcon: const Icon(Icons.lock_outlined, color: kPrimaryColor),
                      suffixIcon: IconButton(
                        icon: Icon(_isObscure ? Icons.visibility_off : Icons.visibility, color: kPrimaryColor),
                        onPressed: () => setState(() => _isObscure = !_isObscure),
                      ),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    validator: (value) => value != null && value.length >= 6 ? null : 'يجب ألا تقل عن 6 خانات',
                  ),
                  const SizedBox(height: 35),

                  // زرار الدخول أو التسجيل
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPrimaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    onPressed: _isLoading ? null : _submitForm,
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(_isLogin ? "دخول" : "تسجيل الحساب", style: const TextStyle(color: Colors.white, fontSize: 18)),
                  ),
                  const SizedBox(height: 20),

                  // تبديل بين تسجيل الدخول وإنشاء حساب
                  TextButton(
                    onPressed: () {
                      setState(() {
                        _isLogin = !_isLogin;
                      });
                    },
                    child: Text(
                      _isLogin ? "ليس لديك حساب؟ املأ بياناتك هنا" : "لديك حساب بالفعل؟ سجل دخولك",
                      style: const TextStyle(color: kPrimaryColor, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}