import 'package:store_app/language_manager.dart';

class Product {
  final int id;
  final double price;
  final String titleAr, titleEn;
  final String subTitleAr, subTitleEn;
  final String descriptionAr, descriptionEn;
  final String image;
  final String category;
  int quantity;
  bool isFavorite;

  Product({
    required this.id,
    required this.price,
    required this.titleAr,
    required this.titleEn,
    required this.subTitleAr,
    required this.subTitleEn,
    required this.descriptionAr,
    required this.descriptionEn,
    required this.image,
    required this.category,
    this.quantity = 1,
    this.isFavorite = false,
  });

  String get title => currentLanguage == "العربية" ? titleAr : titleEn;
  String get subTitle => currentLanguage == "العربية" ? subTitleAr : subTitleEn;
  String get description => currentLanguage == "العربية" ? descriptionAr : descriptionEn;
}

List<Product> products = [
  Product(
    id: 1,
    price: 59,
    titleAr: "سماعات لاسلكية ذكية",
    titleEn: "Smart Wireless Headphones",
    subTitleAr: "صوت محيطي مجسم ثلاثي الأبعاد وعزل متطور للضوضاء",
    subTitleEn: "3D Spatial Audio & Advanced Active Noise Cancellation",
    descriptionAr: "سماعات لاسلكية مريحة للأذن تدعم عزل الضوضاء النشط وبطارية قوية تدوم حتى 40 ساعة متواصلة من الاستماع.",
    descriptionEn: "Comfortable wireless headphones with active noise cancellation and a powerful battery lasting up to 40 hours.",
    image: "images/airpod.png",
    category: "Audio",
  ),
  Product(
    id: 2,
    price: 1099,
    titleAr: "كاميرا تصوير رقمية احترافية",
    titleEn: "Professional Digital Camera",
    subTitleAr: "عدسة سينمائية فائقة الدقة وألوان واقعية مبهرة",
    subTitleEn: "Ultra-HD Cinematic Lens & Stunning Realistic Colors",
    descriptionAr: "أحدث كاميرا ديجيتال لعشاق التصوير الاحترافي وصناع المحتوى، تأتي مع شاشة متحركة ومستشعر متطور للإضاءة المنخفضة.",
    descriptionEn: "The latest digital camera for professional photographers and creators, featuring a flip screen and advanced low-light sensor.",
    image: "images/camera.png",
    category: "Cameras",
  ),
  Product(
    id: 3,
    price: 39,
    titleAr: "نظارات الواقع الافتراضي 3D",
    titleEn: "3D Virtual Reality VR Glasses",
    subTitleAr: "عالم افتراضي متكامل وتجربة ألعاب سينمائية فريدة",
    subTitleEn: "Immersive Virtual World & Unique Cinematic Gaming Experience",
    descriptionAr: "نظارات الواقع الافتراضي المحسنة لمشاهدة الأفلام والألعاب بزاوية 360 درجة وبجودة تضاهي قاعات السينما العالمية.",
    descriptionEn: "Enhanced VR glasses for watching movies and playing games in 360 degrees with a quality matching cinema halls.",
    image: "images/class.png",
    category: "VR",
  ),
  Product(
    id: 4,
    price: 45,
    titleAr: "مكبر صوت ذكي متطور",
    titleEn: "Advanced Smart Speaker",
    subTitleAr: "مساعد منزلي صوتي ذكي وصوت نقي وعالي النقاء",
    subTitleEn: "Voice-Controlled Home Assistant & High-Fidelity Crystal Sound",
    descriptionAr: "مساعد منزلي ذكي وسبيكر نقي يدعم الأوامر الصوتية الذكية والربط السريع مع جميع أجهزتك المنزلية بلمسة واحدة.",
    descriptionEn: "Smart home assistant and pure speaker supporting smart voice commands and fast pairing with all your home devices.",
    image: "images/speaker.png",
    category: "Audio",
  ),
];

List<Product> cartProducts = [];
List<Product> favoriteProducts = [];

String globalUserName = "يوسف صابر";
String globalUserEmail = "youssef@example.com";
dynamic globalProfileImageBytes;
String globalProfileImage = "";