import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'language_manager.dart';
import './screens/signup_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await loadSavedSettings();

  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyAM1JVHuAmMEnjLGfuJ-rdoSBF0hbzMu0k",
      authDomain: "electrical-store-app.firebaseapp.com",
      projectId: "electrical-store-app",
      storageBucket: "electrical-store-app.firebasestorage.app",
      messagingSenderId: "1076833855470",
      appId: "1:1076833855470:web:c8c528ff0c256b76cd50ff",
      measurementId: "G-KS9RJE4L4E",
    ),
  );

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Electrical Store',
      themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,

      // 👈 هنا إجبار التطبيق على فتح اللغة الإنجليزية كـ لغة افتراضية
      locale: const Locale('en', 'US'),
      supportedLocales: const [
        Locale('en', 'US'),
      ],

      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: const Color(0xFF1D93B2),
        scaffoldBackgroundColor: const Color(0xFFF1F5F9),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF121212),
        scaffoldBackgroundColor: const Color(0xFF1E1E1E),
        cardColor: const Color(0xFF2A2A2A),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF121212)),
      ),
      home: const SignUpScreen(),
    );
  }
}