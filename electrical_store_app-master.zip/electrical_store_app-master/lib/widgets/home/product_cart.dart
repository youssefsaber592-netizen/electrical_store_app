import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';
import 'package:store_app/language_manager.dart';

class ProductCard extends StatefulWidget {
  const ProductCard({
    Key? key,
    required this.itemIndex,
    required this.product,
    required this.press,
  }) : super(key: key);

  final int itemIndex;
  final Product product;
  final VoidCallback press;

  @override
  State<ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    // البحث عن المنتج داخل السلة لمعرفة حالته
    int cartIndex = cartProducts.indexWhere((item) => item.id == widget.product.id);
    bool isAddedToCart = cartIndex != -1;
    bool isFav = favoriteProducts.any((item) => item.id == widget.product.id);
    bool isArabic = currentLanguage == "العربية";

    // جلب الكمية الحالية لعرضها كمؤشر فقط
    int displayQuantity = isAddedToCart ? cartProducts[cartIndex].quantity : 1;

    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: kDefaultPadding,
        vertical: kDefaultPadding / 2,
      ),
      height: 190, // ارتفاع ثابت ومثالي للكارت
      child: InkWell(
        onTap: widget.press, // عند الضغط هينتقل لصفحة التفاصيل اللي هتحدد منها الكمية
        child: Stack(
          alignment: Alignment.bottomCenter,
          children: [
            // خلفية الكارت البيضاء
            Container(
              height: 166,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                boxShadow: const [
                  BoxShadow(offset: Offset(0, 15), blurRadius: 25, color: Colors.black12),
                ],
              ),
            ),
            // صورة المنتج على اليسار
            Positioned(
              top: 0,
              left: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding * 1.5),
                height: 160,
                width: 200,
                child: Image.asset(widget.product.image, fit: BoxFit.contain),
              ),
            ),
            // تفاصيل المنتج على اليمين
            Positioned(
              bottom: 0,
              right: 0,
              child: SizedBox(
                height: 145,
                width: size.width - 200,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Spacer(),
                    // السطر الأول: العنوان + أيقونة المفضلة + مؤشر السلة الصغير
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              widget.product.title,
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 16),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          IconButton(
                            constraints: const BoxConstraints(),
                            padding: const EdgeInsets.all(4),
                            icon: Icon(
                              isFav ? Icons.favorite : Icons.favorite_border,
                              color: isFav ? Colors.red : Colors.grey,
                              size: 22,
                            ),
                            onPressed: () {
                              setState(() {
                                if (isFav) {
                                  favoriteProducts.removeWhere((item) => item.id == widget.product.id);
                                } else {
                                  favoriteProducts.add(widget.product);
                                }
                              });
                            },
                          ),
                          if (isAddedToCart)
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.check_circle, color: Colors.green, size: 18),
                                  const SizedBox(height: 1),
                                  Text(
                                    isArabic ? "الكمية: $displayQuantity" : "Qty: $displayQuantity",
                                    style: const TextStyle(
                                        fontSize: 9,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.green
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    // السطر الثاني: الوصف (subTitle)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding),
                      child: Text(
                        widget.product.subTitle,
                        style: Theme.of(context).textTheme.bodySmall,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const Spacer(),
                    // السطر الثالث: السعر فقط بشكل راقٍ ونظيف وبدون زحمة
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding, vertical: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: kSecondaryColor,
                              borderRadius: BorderRadius.circular(22),
                            ),
                            child: Text(
                              isArabic ? 'السعر: \$${widget.product.price}' : 'Price: \$${widget.product.price}',
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}