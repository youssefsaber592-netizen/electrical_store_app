import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';
import 'package:store_app/widgets/home/product_cart.dart';
import 'package:store_app/language_manager.dart';
import 'package:store_app/screens/details_screen.dart'; // السطر ده هيحل خطأ السطر 129 فوراً

class HomeBody extends StatefulWidget {
  const HomeBody({Key? key}) : super(key: key);

  @override
  State<HomeBody> createState() => _HomeBodyState();
}

class _HomeBodyState extends State<HomeBody> {
  String searchQuery = "";
  String selectedCategory = "All";

  @override
  Widget build(BuildContext context) {
    bool isArabic = currentLanguage == "العربية";

    // قائمة التصنيفات الذكية
    List<Map<String, String>> categories = [
      {"en": "All", "ar": "الكل"},
      {"en": "Audio", "ar": "صوتيات"},
      {"en": "Cameras", "ar": "كاميرات"},
      {"en": "VR", "ar": "واقع افتراضي"},
    ];

    // فلترة المنتجات بناءً على البحث والقسم المختار
    List<Product> filteredProducts = products.where((product) {
      bool matchesCategory = selectedCategory == "All" || product.category == selectedCategory;
      bool matchesSearch = product.title.toLowerCase().contains(searchQuery.toLowerCase()) ||
          product.subTitle.toLowerCase().contains(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).toList();

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          // 1. شريط البحث (Search Bar)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding, vertical: 10),
            child: TextField(
              onChanged: (value) => setState(() => searchQuery = value),
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white.withOpacity(0.2),
                hintText: isArabic ? "ابحث عن جهاز ذكي..." : "Search for a smart device...",
                hintStyle: const TextStyle(color: Colors.white70),
                prefixIcon: const Icon(Icons.search, color: Colors.white),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),
              ),
              style: const TextStyle(color: Colors.white),
            ),
          ),

          // 2. قائمة التصنيفات الأفقية (Categories)
          Container(
            height: 40,
            margin: const EdgeInsets.symmetric(vertical: 5),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding / 2),
              itemBuilder: (context, index) {
                bool isSelected = categories[index]["en"] == selectedCategory;
                return GestureDetector(
                  onTap: () => setState(() => selectedCategory = categories[index]["en"]!),
                  child: Container(
                    alignment: Alignment.center,
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: isSelected ? kSecondaryColor : Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      isArabic ? categories[index]["ar"]! : categories[index]["en"]!,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 10),

          // 3. عرض المنتجات المفلترة
          Expanded(
            child: Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 40),
                  decoration: const BoxDecoration(
                    color: kBackgroundColor,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                    ),
                  ),
                ),
                filteredProducts.isEmpty
                    ? Center(
                  child: Text(
                    isArabic ? "لم يتم العثور على منتجات!" : "No products found!",
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kPrimaryColor),
                  ),
                )
                    : ListView.builder(
                  itemCount: filteredProducts.length,
                  itemBuilder: (context, index) => ProductCard(
                    itemIndex: index,
                    product: filteredProducts[index],
                    press: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailsScreen(product: filteredProducts[index]),
                        ),
                      ).then((value) => setState(() {}));
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}