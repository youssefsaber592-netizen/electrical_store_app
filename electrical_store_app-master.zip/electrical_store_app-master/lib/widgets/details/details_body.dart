import 'package:flutter/material.dart';
import 'package:store_app/constants.dart';
import 'package:store_app/models/product.dart';
import 'package:store_app/language_manager.dart';
import 'product_image.dart';

class DetailsBody extends StatefulWidget {
  final Product product;
  const DetailsBody({Key? key, required this.product}) : super(key: key);

  @override
  State<DetailsBody> createState() => _DetailsBodyState();
}

class _DetailsBodyState extends State<DetailsBody> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding * 1.5),
            decoration: const BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(50),
                bottomRight: Radius.circular(50),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: ProductImage(size: size, image: widget.product.image)),
                // أزرار التحكم في العدد
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () { setState(() { widget.product.quantity++; }); },
                      icon: const Icon(Icons.add_circle, color: kPrimaryColor, size: 40),
                    ),
                    Text('${widget.product.quantity}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                    IconButton(
                      onPressed: () { setState(() { if (widget.product.quantity > 1) widget.product.quantity--; }); },
                      icon: const Icon(Icons.remove_circle, color: Colors.red, size: 40),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: kDefaultPadding / 2),
                  child: Text(widget.product.title, style: Theme.of(context).textTheme.headlineSmall),
                ),
                Text('السعر: \$${widget.product.price}', style: const TextStyle(fontSize: 28.0, fontWeight: FontWeight.w600, color: kSecondaryColor)),
                const SizedBox(height: kDefaultPadding),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(kDefaultPadding * 1.5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.product.description, style: const TextStyle(color: Colors.white, fontSize: 19.0)),
                const SizedBox(height: 30),
                // زرار الإضافة إلى السلة الاحترافي
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kSecondaryColor,
                    minimumSize: const Size(double.infinity, 55),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  icon: const Icon(Icons.add_shopping_cart, color: Colors.white),
                  label: Text(getTranslated("add_to_cart"), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  onPressed: () {
                    // التحقق لو المنتج موجود نحدث الكمية، لو مش موجود نضيفه
                    if (!cartProducts.contains(widget.product)) {
                      cartProducts.add(widget.product);
                    }
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(getTranslated("added_success")),
                        backgroundColor: Colors.green,
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}